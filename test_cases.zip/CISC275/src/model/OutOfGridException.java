package model;

public class OutOfGridException extends RuntimeException {

}
