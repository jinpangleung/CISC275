package model;

public class Player {
	private int estuaryHealth;
	private double gameTime;
	private int oysterCount;
	
	public int getEstuaryHealth() {
		return estuaryHealth;
	}

	public void setEstuaryHealth(int estuaryHealth) {
		this.estuaryHealth = estuaryHealth;
	}

	public double getGameTime() {
		return gameTime;
	}

	public void setGameTime(double gameTime) {
		this.gameTime = gameTime;
	}

	public void update() {
		//TODO same thing with update passing elapsedTickTime - Gifan
		//gameTime = gameTime - elapsedTickTime;
		// I think it is more efficient to use System.currentTimeMillis rather than constantly passing around
		// how much time has passed in the game.
		// Store the time in which the game started with System.currentTimeMillis
		// Then at any point, the total running time of the game is System.currentTimeMillis - startTime - Eric
	}
	
	public void increaseOysterCount(){
		oysterCount++;
	}
	
	

}
