package model;

public class Storm {

}
