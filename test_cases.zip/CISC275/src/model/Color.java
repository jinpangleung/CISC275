package model;

public enum Color {
	WHITE, RED, GREEN, BLUE
	//White = larvae
	//Red = pollutant
	//Green = Invasive item
	//Blue = oyster
}
