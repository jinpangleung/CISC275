package gabions;

public class ConcreteGabion extends Gabion {
	
	public ConcreteGabion(){
		health = 1;
	}
}
