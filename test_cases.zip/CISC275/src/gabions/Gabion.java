package gabions;

import model.GridItem;

public abstract class Gabion extends GridItem {
	
	//// Attributes ////
	protected int health;
	
	//// Setters and Getters ////
	public int getHealth(){
		return this.health;
	}

	public void update(){
		// do nothing
	}
}
