package towers;

import model.Color;

public class BlueTower extends Tower{
	
	public BlueTower(){
		color = Color.BLUE;
		cooldownRemaining = 10;
		range = 10;
	}
	
	@Override
	public void ability(){
		// TODO
	}
}
