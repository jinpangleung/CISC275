package towers;

import model.Color;

public class RedTower extends Tower {

	public RedTower(){
		color = Color.RED;
		cooldownRemaining = 10;
		range = 10;
	}
	
	@Override
	public void ability(){
		//TODO
	}
}
