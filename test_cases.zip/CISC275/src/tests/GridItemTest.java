package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class GridItemTest {

	@Test
	public void testGetPosn() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPixelPosn() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAnimation() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetPosn() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetPixelPosn() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetAnimation() {
		fail("Not yet implemented");
	}

	@Test
	public void testDraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdate() {
		fail("Not yet implemented");
	}

}
