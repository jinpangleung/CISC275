package cisc275_final;

public enum Color {
	WHITE, RED, GREEN, BLUE
}
