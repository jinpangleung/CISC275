package cisc275_final;

public class GreenTower extends Tower{

}
