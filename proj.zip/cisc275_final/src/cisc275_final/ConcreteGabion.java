package cisc275_final;

public class ConcreteGabion extends Gabion {

}
