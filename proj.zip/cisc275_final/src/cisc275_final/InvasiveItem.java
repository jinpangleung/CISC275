package cisc275_final;

public class InvasiveItem extends TrailItem {

}
