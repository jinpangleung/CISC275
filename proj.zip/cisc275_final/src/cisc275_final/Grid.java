package cisc275_final;
import java.awt.*;
import java.util.*;

/*
 * Notes
 */

public class Grid {
	
	//// Attributes ////
	private Position[][] positions;
	private Collection<GridItem> items;
	private Player player;
	private PixelGrid pixelGrid;
	//// Attributes ////
	
	//// Getters and Setters ////
	public Position[][] getPositions(){
		return positions;
	}
	public Collection<GridItem> getItems(){
		return items;
	}
	public Player getPlayer(){
		return player;
	}
	public PixelGrid getPixelGrid(){
		return pixelGrid;
	}
	//// Getters and Setters ////
	
	//// Methods ////
	public void update(){
		// TODO
	}
	public void draw(Graphics g){
		// TODO
	}
	public void clickHandler(int mouseX, int mouseY){
		// TODO
	}
	//// Methods ////

}
