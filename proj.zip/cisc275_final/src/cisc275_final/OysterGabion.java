package cisc275_final;

public class OysterGabion extends Gabion {

}
