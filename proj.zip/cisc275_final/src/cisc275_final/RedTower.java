package cisc275_final;

public class RedTower extends Tower {

}
