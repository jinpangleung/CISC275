package cisc275_final;

public class BlueTower extends Tower{

}
