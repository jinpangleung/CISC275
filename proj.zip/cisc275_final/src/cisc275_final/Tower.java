package cisc275_final;

public abstract class Tower extends GridItem {
	
	//// Attributes ////
	private Color color;
	private int cooldownRemaining;
	
	//// Methods ////
	
	public void ability(){
		
	}
	@Override
	public void update(){
		// TODO
	}
}
