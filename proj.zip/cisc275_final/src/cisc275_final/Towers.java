package cisc275_final;

public class Towers {
	
	//// Attributes ////
	private int numberOfGreenTowers;
	private int numberOfRedTowers;
	private int numberOfBlueTowers;
	
	//// Getters ////
	public int getNumberOfGreenTowers() {
		return numberOfGreenTowers;
	}
	public int getNumberOfRedTowers() {
		return numberOfRedTowers;
	}
	public int getNumberOfBlueTowers() {
		return numberOfBlueTowers;
	}
	
	//// Methods ////
	public boolean towersRemaining(Color color){
		return false;
		// TODO
	}
	public void placeTower(Color color){
		// TODO
	}
	

}
