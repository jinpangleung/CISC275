package cisc275_final;

public class Oyster extends TrailItem {
	
	//// Methods ////
	@Override
	public void click(){
		// TODO
	}

}
