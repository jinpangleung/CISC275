package cisc275_final;

public class Larvae extends TrailItem {

}
