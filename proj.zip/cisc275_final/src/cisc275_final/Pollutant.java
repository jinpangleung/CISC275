package cisc275_final;

public class Pollutant extends TrailItem {

}
