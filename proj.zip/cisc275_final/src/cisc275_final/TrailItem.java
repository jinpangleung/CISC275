package cisc275_final;

public class TrailItem extends GridItem {
	
	//// Attributes ////
	private int health;
	private int speed;
	private boolean isBad;
	private Color color;
	
	//// Constants ////
	private final int CLICKDAMAGE = 1;
	
	//// Getters ////
	public int getHealth(){
		return health;
	}
	public int getSpeed(){
		return speed;
	}
	public boolean getIsBad(){
		return isBad;
	}
	public Color getColor(){
		return color;
	}
	
	//// Methods ////
	public void damage(){
		// TODO
	}
	public void click(){
		// TODO
	}

}
