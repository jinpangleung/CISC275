package cisc275_final;

public abstract class Gabion extends GridItem {
	
	//// Attributes ////
	private int health;
	
	//// Setters and Getters ////
	public int getHealth(){
		return health;
	}
	public void setHealth(int h){
		this.health = h;
	}

}
