package gabions;

public class ConcreteGabion extends Gabion {
	
	public ConcreteGabion(){
		health = 1;
	}
	
	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
}
