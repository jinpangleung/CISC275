package model;

public class OutOfGridException extends RuntimeException {

	private static final long serialVersionUID = 8467246291296770781L;

}
