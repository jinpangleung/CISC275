package model;

public enum PathBehavior {
	STRAIGHT
}
