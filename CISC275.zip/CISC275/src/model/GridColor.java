package model;

public enum GridColor {
	WHITE, RED, GREEN, BLUE
	//White = all
	//Red = pollutant
	//Green = Invasive item
	//Blue = oyster
}
