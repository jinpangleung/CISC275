package model;

public class InvalidCellException extends RuntimeException{


	private static final long serialVersionUID = 3454878183176971034L;
	
	

}
