package model;

public enum PathTermination {
	DESTROY, TO_GRID
}
