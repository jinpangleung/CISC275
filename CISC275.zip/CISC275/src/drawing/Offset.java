package drawing;

public enum Offset {
	
	CENTER

}
